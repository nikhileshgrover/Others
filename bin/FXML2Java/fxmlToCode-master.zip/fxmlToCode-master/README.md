# fxmlToCode
Simple Java application to convert an FXML scene into procedural JavaFX code.

# Attention
This project is in the _very_ early stages.
